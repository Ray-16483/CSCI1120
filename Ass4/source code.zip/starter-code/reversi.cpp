// Name:       xxx
// Student ID: xxxxxxxxxx
// Email:      xxx

#include <iostream>
#include <iomanip>
#include <limits>
#include "reversi.h"

/* You may include more headers here if necessary. */

using namespace std;

// Return true if console input fails (e.g., the user enters alphabets while 
// an integer is expected.) or false otherwise
// This function bypasses any weird input by skipping to the next newline  
bool cin_failed() {
    bool failed = cin.fail();
    if (failed) {
        cin.clear();  // clear the error flag on cin
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // skip to next newline
    }
    return failed;    
}

// Print the game board
void print_board(char board[][N]) {
    cout << "  ";
    for (int i = 0; i < N; i++)
        cout << setw(2) << char('A'+i);
    cout << endl;
    for (int i = 0; i < N; i++) {
        cout << setw(2) << i + 1 << ' ';
        for (int j = 0; j < N; j++)
            cout << board[i][j] << ' ';
        cout << endl;
    }
}

// Return true if the move by player p at cell (y, x) is valid, or false otherwise 
// If flip is passed as true, the move is made on the board
bool valid_move(char board[][N], char p, int y, int x, bool flip) {
    // TODO:
}

// Return true if player p still has valid move(s) on the board, or false otherwise
bool has_valid_moves(char board[][N], char p) {
    // TODO: 
}

// Return true if the game board still has empty cell(s), or false otherwise
bool has_empty_cells(char board[][N]) {
    // TODO:
}
